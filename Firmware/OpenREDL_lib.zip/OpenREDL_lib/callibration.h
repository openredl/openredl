int callibration_address = 101;
float cal_n[]={1,1,1,1,1,1};// callibration values for each channel
int meas_count=0;
float meas, mean;
float cal=0.0;

void read_cal_FromEEPROM()// read callibration values from eeprom
{
    int current_address = callibration_address ;
    int arraySize = sizeof(cal_n) / sizeof(float);
    for (int i = 0; i < arraySize; i++) {
        EEPROM.get(current_address, cal_n[i]);
        current_address += sizeof(float);
    }
}

void write_cal_toEEPROM()
{ 

    int arraySize = sizeof(cal_n) / sizeof(float);
    int current_address = callibration_address;
    for (int i = 0; i < arraySize; i++) {
        EEPROM.put(current_address, cal_n[i]);
        current_address += sizeof(float);
    }
}

void general_calibration(float meas){
        float new_cal = meas/mean;
        meas_count++;
        
        Serial.print(F("I<new cal meas: "));
        Serial.print(meas,6);
        Serial.print(F(">\n"));

        Serial.print(F("I<old cal: "));
        Serial.print(cal,6);
        Serial.print(F(">\n"));
        
        cal = (new_cal + cal * (meas_count-1))/(meas_count);
        
        Serial.print(F("I<New cal: "));
        Serial.print(cal,6);
        Serial.print(F(">\n"));
}

void perchannel_calibration(float meas){
    float new_cal[] = {meas/diff1.mean_sample_unit(),
                       meas/diff2.mean_sample_unit(),
                       meas/diff3.mean_sample_unit(),
                       meas/diff4.mean_sample_unit(),
                       meas/diff1.mean_sample_unit(),
                       meas/diff1.mean_sample_unit()
                      };
    
    //float new_cal = meas/meas_n[case_n-1];
    meas_count++;
    
    Serial.print(F("I<new cal meas: "));
    Serial.print(meas,6);
    Serial.print(F(">\n"));

    for (int i=0; i<6; i++){       
        cal_n[i] = (new_cal[i] + cal_n[i] *
                           (meas_count-1)
                          )/(meas_count);

        Serial.print(F(",DIFF"));
        Serial.print(i+1);
        Serial.print(F(":"));
        Serial.print(cal_n[i],6);
        Serial.println();
    }
}

void store_callibration(){
    write_cal_toEEPROM();
    read_cal_FromEEPROM();
    for (int i=0; i<6; i++){       
        Serial.print(F(",DIFF"));
        Serial.print(i+1);
        Serial.print(F(":"));
        Serial.print(cal_n[i],6);
        Serial.println();
    }
}
