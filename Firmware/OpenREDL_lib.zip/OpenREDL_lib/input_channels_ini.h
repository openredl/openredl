typedef enum InputChannel_tag {
    ch_diff1,
    ch_diff2,
    ch_diff3,
    ch_diff4,
    ch_diff5,
    ch_diff6,
    ch_se1,
    ch_se2,
    ch_se3,
    ch_se4,
    ch_se5,
    ch_se6,
    ch_se7,
    ch_se8,
    ch_se9,
    ch_se10,
    ch_se11,
    ch_se12,
    ch_d1,
    ch_d2,
    ch_d3,
    ch_d4,
    ch_d5
} InputChannel_te;

//TODO: create channel subclass for GPIOs
//#######################################
// GPIO configuration, for DL23 GBE
//#######################################
const byte ch_d1_pin = 3; // digital I/O, PWM, pulse counter
const byte ch_d2_pin = 4; // digital I/O, 
const byte ch_d3_pin = 5; // digital I/O, PWM
const byte ch_d4_pin = 14;// digital I/O, ADC
const byte ch_d5_pin = 15;// digital I/O, ADC

// For d1 as pulse counter
volatile unsigned long pulses_counter;
unsigned long us_pulse, us_start, us_end, us_sum;
void pulseCounter() {
  us_pulse = micros();
  pulses_counter++;
}

void init_digital_pins(){
   pinMode(ch_d1_pin, INPUT);
   pinMode(ch_d2_pin, INPUT);
   pinMode(ch_d3_pin, INPUT);
   pinMode(ch_d4_pin, INPUT);
   pinMode(ch_d5_pin, INPUT);
   
   //for pulses count
   pinMode(ch_d1_pin, INPUT_PULLUP);
   attachInterrupt(digitalPinToInterrupt(ch_d1_pin), pulseCounter, RISING);
//    digitalWrite(d_ch1, !digitalRead(d_ch1));
//    digitalWrite(d_ch2, !digitalRead(d_ch2));
//    digitalWrite(d_ch3, !digitalRead(d_ch3));
//    digitalWrite(d_ch4, !digitalRead(d_ch4));
//    digitalWrite(d_ch5, !digitalRead(d_ch5));
   //if (digitalRead(16) == HIGH) Serial.println(F("REMOVE BUTON PRESSED"));   
}


//##################################
//Mapping of channels to get samples
//##################################
int16_t getSample(InputChannel_te ch_tag){
    switch (ch_tag){
    case (ch_diff1): return ads4A.getConversionP0N1();
    case (ch_diff2): return ads4A.getConversionP2N3();
    case (ch_diff3): return ads4B.getConversionP0N1();
    case (ch_diff4): return ads4B.getConversionP2N3();
    case (ch_diff5): return ads4C.getConversionP0N1();
    case (ch_diff6): return ads4C.getConversionP2N3();
    case (ch_se1): return ads4A.getConversionP0GND();
    case (ch_se2): return ads4A.getConversionP1GND();
    case (ch_se3): return ads4A.getConversionP2GND();
    case (ch_se4): return ads4A.getConversionP3GND();
    case (ch_se5): return ads4B.getConversionP0GND();
    case (ch_se6): return ads4B.getConversionP1GND();
    case (ch_se7): return ads4B.getConversionP2GND();
    case (ch_se8): return ads4B.getConversionP3GND();
    case (ch_se9): return ads4C.getConversionP0GND();
    case (ch_se10): return ads4C.getConversionP1GND();
    case (ch_se11): return ads4C.getConversionP2GND();
    case (ch_se12): return ads4C.getConversionP3GND();
    case (ch_d1): return pulses_counter;
    case (ch_d4): return analogRead(ch_d4_pin);
    case (ch_d5): return analogRead(ch_d5_pin);
    default: return 0;
    }
}

//#######################################
//Instructions that must be executed to prepare channel for sampling
//#######################################
int16_t prepareCh(InputChannel_te ch_tag, uint8_t gain){
    switch (ch_tag){
    case (ch_diff1): {ads4A.setGain(gain);break;}
    case (ch_diff2): {ads4A.setGain(gain);break;}
    case (ch_diff3): {ads4B.setGain(gain);break;}
    case (ch_diff4): {ads4B.setGain(gain);break;}
    case (ch_diff5): {ads4C.setGain(gain);break;}
    case (ch_diff6): {ads4C.setGain(gain);break;}
    case (ch_se1): {ads4A.setGain(gain);break;}
    case (ch_se2): {ads4A.setGain(gain);break;}
    case (ch_se3): {ads4A.setGain(gain);break;}
    case (ch_se4): {ads4A.setGain(gain);break;}
    case (ch_se5): {ads4B.setGain(gain);break;}
    case (ch_se6): {ads4B.setGain(gain);break;}
    case (ch_se7): {ads4B.setGain(gain);break;}
    case (ch_se8): {ads4B.setGain(gain);break;}
    case (ch_se9): {ads4C.setGain(gain);break;}
    case (ch_se10): {ads4C.setGain(gain);break;}
    case (ch_se11): {ads4C.setGain(gain);break;}
    case (ch_se12): {ads4C.setGain(gain);break;}    
    case (ch_d4): {pinMode(ch_d4_pin, INPUT);break;}
    case (ch_d5): {pinMode(ch_d5_pin, INPUT);break;}
    default: return 0;
    }
}

//#######################################
//Mapping of channels to get mV per count
//#######################################
float getmVperCount(InputChannel_te ch_tag, uint8_t gain){
    switch (ch_tag){
    case (ch_diff1): {ads4A.setGain(gain); return ads4A.getMvPerCount();}
    case (ch_diff2): {ads4A.setGain(gain); return ads4A.getMvPerCount();}
    case (ch_diff3): {ads4B.setGain(gain); return ads4B.getMvPerCount();}
    case (ch_diff4): {ads4B.setGain(gain); return ads4B.getMvPerCount();}
    case (ch_diff5): {ads4C.setGain(gain); return ads4C.getMvPerCount();}
    case (ch_diff6): {ads4C.setGain(gain); return ads4C.getMvPerCount();}
    case (ch_se1): {ads4A.setGain(gain); return ads4A.getMvPerCount();}
    case (ch_se2): {ads4A.setGain(gain); return ads4A.getMvPerCount();}
    case (ch_se3): {ads4A.setGain(gain); return ads4A.getMvPerCount();}
    case (ch_se4): {ads4A.setGain(gain); return ads4A.getMvPerCount();}
    case (ch_se6): {ads4B.setGain(gain); return ads4B.getMvPerCount();}
    case (ch_se5): {ads4B.setGain(gain); return ads4B.getMvPerCount();}
    case (ch_se7): {ads4B.setGain(gain); return ads4B.getMvPerCount();}
    case (ch_se8): {ads4B.setGain(gain); return ads4B.getMvPerCount();}
    case (ch_se9): {ads4C.setGain(gain); return ads4C.getMvPerCount();}
    case (ch_se10): {ads4C.setGain(gain); return ads4C.getMvPerCount();}
    case (ch_se11): {ads4C.setGain(gain); return ads4C.getMvPerCount();}
    case (ch_se12): {ads4C.setGain(gain); return ads4C.getMvPerCount();}    
    case (ch_d1): {return 1.;}
    case (ch_d4): {return 5./1023.;}
    case (ch_d5): {return 5./1023.;}
    default: return 0.;
    }
}

float PT100 = 100.;
float PT1000 = 1000.;

float calculate_Pt_RtoC(float R,float R0) {
    //Get Temperature in celcius from:
    //    R: Measured resistance in Ohms
    //    R0: Platinium Sensor Reference resistance in Ohms at 0°C
    // Discarding C factor. Error for-100C->0.222C, for 100C->0.015C.
    float A=3.9083E-3; 
    float B=-5.775E-7; 
    return ((-A + sqrt((A*A) - 4.0 * B * (1.0 - R/R0))) / (2.0 * B));
}


//################
//Not used
/////////////////

//byte _mV = 1;
//byte _V = 2;
//byte _mA = 3;
//byte _A = 4;
//byte _mW = 5;
//byte _W = 6;
//
//String units_map(byte _units){
//    switch(_units){
//        case 1: return "mV";
//        case 2: return "V";
//        case 3: return "mA";
//        case 4: return "A";        
//        case 5: return "mW";
//        case 6: return "W";
////        case 7: return "mA";
////        case 8: return "A";
//    }
//    return "";
//}












