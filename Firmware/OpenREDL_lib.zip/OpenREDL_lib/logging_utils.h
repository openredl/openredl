void serial_print_progmem(const char txt[]){
    char temp_Char;
    for (byte k = 0; k < strlen_P(txt); k++) {
        temp_Char = pgm_read_byte_near(txt + k);
        Serial.print(temp_Char);
    }
}


void myfile_print_progmem(char txt[]){
   char temp_Char;
   for (byte k = 0; k < strlen_P(txt); k++) {
       temp_Char = pgm_read_byte_near(txt + k);
       myFile.print(temp_Char);

   }
}

void headers_to_log(int log_num){
     if (format_log == TIMESERIES){
        format_log = TIMESERIES_HEADERS;
        select_log = log_num;
        add_to_log(F("H<datetime,"));
        to_log_content();
        add_to_log(F("notes>\n"));
        format_log = TIMESERIES;
     }
}

void to_log_start(){
    // add_to_log(F("M>"));//Meassurement line indicator
    // add_to_log(dt);
    // add_to_log(tm);
    if (format_log ==JSON){
        add_to_log(F("M<{\"datetime\":\""));//Meassurement line indicator
        add_to_log(dt);
        add_to_log(tm);
        
        // add ms to time if storage_interval_s<1
        if (storage_interval_s<1){
            unsigned long lapse = millis()-millis_last_second_update;
            add_to_log(".");
            if (lapse<100) add_to_log(0);
            else if (lapse>999) lapse = 999;
            add_to_log(lapse);
            //add_to_log("\"");
            }        
    }
    else{ // TIMESERIES FORMAT as default for any other value
        add_to_log(F("M<"));//Meassurement line indicator
        add_to_log(dt);
        add_to_log(tm);

        // add ms to time if storage_interval_s<1
        if (storage_interval_s<1){
            unsigned long lapse = millis()-millis_last_second_update;
            add_to_log(".");
            if (lapse<100) add_to_log(0);
            else if (lapse>999) lapse = 999;
            add_to_log(lapse);
            //add_to_log("\"");
            }        
        add_to_log(F(","));
    }

}


void to_log_end(){
    // add_to_log(F(","));        
    //add_to_log(count_sampling_rounds);
    // add_to_log(F(","));
    if (select_log == 1){
       if (format_log == JSON){
          if (stored_in_SD) add_to_log(F(", \"note\":\"Stored in SD\""));
          else add_to_log(F(", \"note\":\"NOT stored in SD\""));
       }
       else{
          if (stored_in_SD) add_to_log(F("Stored in SD"));
          else add_to_log(F("NOT stored in SD"));
       }
    }

    if (format_log ==JSON) add_to_log(F("}"));//Meassurement line indicator

    add_to_log(F(">\n"));

}


void print_log(int log_num){
  // lognum=1 is Serial, lognum=2 is myfile in SD card
  
    select_log = log_num;
    to_log_start();
    to_log_content();
    to_log_end();
  }
  
 void send_log_to_serial(){
//    Serial.println((now.second()+60*now.minute())%(storage_interval_s));
    print_log(1);  
}


 void send_log_to_sdcard(){
 //    Serial.println("[debug]Starting to store in SD.");

    myFile = SD.open(file_n, FILE_WRITE);
    //if (Serial.available()) handle_serial_input();


    // Serial.print(F("\n[debug] File_n exists in SD Card: "));
    // Serial.println(SD.exists(file_n));

    if (!myFile) {
        // Serial.println(F("[debug] Myfile is false"));
         Serial.println(F("[ALERT] Sample Not Stored. SD Card not opened."));
         stored_in_SD = 0;
         init_SDcard();
    }

     else { 
//         Serial.println(F("[debug] Myfile is true")); 
        print_log(2);
        stored_in_SD = 1;
    }
    myFile.close();

}
