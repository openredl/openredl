//-----------------------------------------------------------
// CHANNELS CONFIGURATION
// Define the parameters for each channel
//-----------------------------------------------------------
#ifdef diff1
#undef diff1
INPUTCHANNEL diff1(
    ch_diff1,            //String channel = "DIFF1";
    ADS1115_PGA_6P144,  //uint8_t gain = ADS1115_PGA_6P144;
    0.,                  //float offset = 0;
    1.                  //float mult_factor = 1;
    //"mV"                //String units = "mV"
);
#endif

#ifdef diff2
#undef diff2
INPUTCHANNEL diff2(
    ch_diff2,            //String channel = "DIFF2";
    ADS1115_PGA_6P144,  //uint8_t gain = ADS1115_PGA_6P144;
    0.,                  //float offset = 0;
    1.                  //float mult_factor = 1;
    //"mV"                //String units = "mV"
);
#endif

#ifdef diff3
#undef diff3
INPUTCHANNEL diff3(
    ch_diff3,            //String channel = "DIFF3";
    ADS1115_PGA_6P144,  //uint8_t gain = ADS1115_PGA_6P144;
    0.,                  //float offset = 0;
    1.                  //float mult_factor = 1;
    //_mV                //String units = "mV"
);
#endif

#ifdef diff4
#undef diff4
INPUTCHANNEL diff4(
    ch_diff4,            //String channel = "DIFF4";
    ADS1115_PGA_6P144,  //uint8_t gain = ADS1115_PGA_6P144;
    0.,                  //float offset = 0;
    1.                   //float mult_factor = 1;
    //_mV                //String units = "mV"
);
#endif

#ifdef diff5
#undef diff5
INPUTCHANNEL diff5(
    ch_diff5,            //String channel = "DIFF4";
    ADS1115_PGA_6P144,  //uint8_t gain = ADS1115_PGA_6P144;
    0.,                  //float offset = 0;
    1.                 //float mult_factor = 1;
    //_mV                //String units = "mV"
);
#endif

#ifdef diff6
#undef diff6
INPUTCHANNEL diff6(
    ch_diff6,            //String channel = "DIFF4";
    ADS1115_PGA_6P144,  //uint8_t gain = ADS1115_PGA_6P144;
    0.,                  //float offset = 0;
    1.                 //float mult_factor = 1;
    //_mV                //String units = "mV"
);
#endif

#ifdef se1
#undef se1
INPUTCHANNEL se1(
    ch_se1,            //String channel = "DIFF4";
    ADS1115_PGA_6P144,  //uint8_t gain = ADS1115_PGA_6P144;
    0.,                  //float offset = 0;
    1.                 //float mult_factor = 1;
    //_mV                //String units = "mV"
);
#endif

#ifdef se2
#undef se2
INPUTCHANNEL se2(
    ch_se2,            //String channel = "DIFF4";
    ADS1115_PGA_6P144,  //uint8_t gain = ADS1115_PGA_6P144;
    0.,                  //float offset = 0;
    1.                 //float mult_factor = 1;
    //_mV                //String units = "mV"
);
#endif
//INPUTCHANNEL se3(
//    ch_se3,            //String channel = "DIFF4";
//    ADS1115_PGA_6P144,  //uint8_t gain = ADS1115_PGA_6P144;
//    0.,                  //float offset = 0;
//    1.                 //float mult_factor = 1;
//    //_mV                //String units = "mV"
//);

//INPUTCHANNEL se4(
//    ch_se4,            //String channel = "DIFF4";
//    ADS1115_PGA_6P144,  //uint8_t gain = ADS1115_PGA_6P144;
//    0.,                  //float offset = 0;
//    1.                 //float mult_factor = 1;
//    //_mV                //String units = "mV"
//);


#ifdef d1
#undef d1
INPUTCHANNEL d1(
    ch_d1,            //String channel = "DIFF4";
    0,  //uint8_t gain = ADS1115_PGA_6P144;
    0.,                  //float offset = 0;
    1.                 //float mult_factor = 1;
    //_mV                //String units = "mV"
);
#endif

#ifdef d4
#undef d4
INPUTCHANNEL d4(
    ch_d4,            //String channel = "DIFF4";
    0,  //uint8_t gain = ADS1115_PGA_6P144;
    0.,                  //float offset = 0;
    1.                 //float mult_factor = 1;
    //_mV                //String units = "mV"
);
#endif

#ifdef d5 
#undef d5
INPUTCHANNEL d5(
    ch_d5,            //String channel = "DIFF4";
    0,  //uint8_t gain = ADS1115_PGA_6P144;
    0.,                  //float offset = 0;
    1.                 //float mult_factor = 1;
    //_mV                //String units = "mV"
);
#endif

#ifdef phase1
#undef phase1
AC_phase phase1(&diff1,&diff4); // (I_channel, V_channel) - their offset and multiplication factor must deliver a value in V and A.
#endif

#ifdef phase2
#undef phase1
AC_phase phase2(&diff2,&diff5); // (I_channel, V_channel) - their offset and multiplication factor must deliver a value in V and A.
#endif

#ifdef phase3
#undef phase3
AC_phase phase3(&diff3,&diff6); // (I_channel, V_channel) - their offset and multiplication factor must deliver a value in V and A.
#endif

