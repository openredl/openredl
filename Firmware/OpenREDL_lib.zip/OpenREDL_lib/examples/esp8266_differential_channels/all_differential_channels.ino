//before committing, test:
//- if sample max and min are working correctly for diff channels (changed from float to int)
//- if size of channels objects can still be reduced, to add a 3rd phase

#define FIRMWARE_DESCRIPTION "Continuous sampling of 6 differential channels, "\
                             "storing at 10 seconds interval."

//#define diff5
//#define diff6
#include "/home/aj/Nextcloud/Laptop/PPRE_Laptop/repos/OpenREDL_github/Firmware/OpenREDL_lib/datalogger_config.h"

#define manage_params_on
#include "dl_libs.h"
#include <ESP8266WiFi.h>
#define DEVICE "ESP8266"
#include <InfluxDbClient.h>
#include <InfluxDbCloud.h>
InfluxDBClient dbclient;
#define WRITE_PRECISION WritePrecision::S
#define MAX_BATCH_SIZE 400
#define WRITE_BUFFER_SIZE 400
#define FLUSH_INTERVAL 60
Point sensor("INITname");

void declare_default_params() {
        //add_json_object("WIFI_SSID", "uPesy_AP");
        //add_json_object("WIFI_PSW", "super_strong_password");
        //add_json_object("WIFI_SSID", "Redmilul");
        //add_json_object("WIFI_PSW", "12321internet45654");   

        add_json_object("WIFI_SSID", "Tzintzuntzan_2.4Gnormal");
        add_json_object("WIFI_PSW", "Jimenez2023");  
        add_json_object("INFLUXDB_URL", "https://influxdb.olegeno.de");
        add_json_object("INFLUXDB_ORG", "org");
        add_json_object("INFLUXDB_TOKEN", "pdYEz3D1XZVo-qQqI0RDoHzGTwW1njfDYuJa2wTRNgwSwL3lFvX6lvw_xwgsTev5YYhBr18-rzikleoTJdVxHg==");
        add_json_object("INFLUXDB_BUCKET", "aj_measurements");
        add_json_object("TZ_INFO", "CET-1CEST,M3.5.0,M10.5.0/3");
        add_json_object("SENSORNAME", "dl_esp8266_rms1");
        add_json_object("WIFIHOSTNAME", "dl_esp8266_onewire_1_test");
        add_json_object("SERIALBAUDRATE", "115200");
        add_json_object("log_interval_ms", "60000"); 
        add_json_object("firmware", "ESP8266_DL_TEMPONEWIREv:231129"); 
        add_json_object("LOCATION", "salomon"); 

}

//Setup function runs one time at the microporocessor start-up
void setup() {
  
  format_log = TIMESERIES; // TIMESERIES or JSON
  // storage_interval_s: Default 10 (s), minimum ~0.1(s)
  // below 1s has lower time precision.
  storage_interval_s = 30; 

//##############################################################################
// CONFIGURATION OF ANALOG CHANNELS
//##############################################################################
//For each differential channel you can change:
//diffx.gain: ADC meassuring range, defined by the sensor maximum possible output.
//Default ADS1115_PGA_2P048
//diffx.offset: float, an addig offset of the sensor. Default 0.
//diffx.mult_factor: FLOAT, the multiplication factor to convert measurements,
//from the sensor callibration. Default 1.
//diffx.units: STRING, describes the measurement units. Default "mV".

// The ADC input range (or gain) can be changed via the following
// options, but be careful never to exceed VDD +0.3V max
// (5V if using USB power), or to exceed the upper and lower limits
// if you adjust the input range!
// Setting these values incorrectly may destroy your ADC!
//Gain sets the range to Possible values to be measured. 4p096 meand a range of 4.096V
//------------------|----------|------------|-------------------
//       Gain       |          |    Range   |      Resolution      
//------------------|----------|------------|-------------------
//ADS1115_PGA_6P144 | 2/3x gain| +/- 6.144V | 1 bit = 0.1875mV (default)
//ADS1115_PGA_4P096 | 1x gain  | +/- 4.096V | 1 bit = 0.125mV
//ADS1115_PGA_2P048 | 2x gain  | +/- 2.048V | 1 bit = 0.0625mV
//ADS1115_PGA_1P024 | 4x gain  | +/- 1.024V | 1 bit = 0.03125mV
//ADS1115_PGA_0P512 | 8x gain  | +/- 0.512V | 1 bit = 0.015625mV
//ADS1115_PGA_0P256 | 16x gain | +/- 0.256V | 1 bit = 0.0078125mV
//------------------|----------|------------|-------------------
//#### GAIN (Range of measurements inputs) ####

//diff1.gain = ADS1115_PGA_6P144;
//diff2.gain = ADS1115_PGA_6P144;
//diff3.gain = ADS1115_PGA_6P144;
//diff4.gain = ADS1115_PGA_6P144;
diff5.gain = ADS1115_PGA_0P256;
diff6.gain = ADS1115_PGA_0P256;

//#### Multiplication factor (Sensor calibration factor) ####
//todo: fix not working properly if not decimals
// Callibration for each input channel. Value_unit = (mult_factor x VoltageMeasured) + offset

//diff1.mult_factor = 1.;
//diff2.mult_factor = 1.;
//diff3.mult_factor = 1.;
//diff4.mult_factor = 1.;
diff5.mult_factor = 80./333.;
diff6.mult_factor = 80./333.;

//#### OFFSET (Offset to add, should be in the final calculation units e.g. °C, V. mV) ####
//diff1.offset_unit = 0.;
//diff2.offset_unit = 0.;
//diff3.offset_unit = 0.;
//diff4.offset_unit = 0.;
//diff5.offset_unit = 0.;
//diff6.offset_unit = 0.;
//##############################################################################

  init_dl(); // initialize the DL routines and parameters

    setup_dl_libs();
    WiFi.begin(get_param("WIFI_SSID", chr),
               get_param("WIFI_PSW", chr)
               );
    wifi_station_set_hostname(get_param("WIFIHOSTNAME", chr));
    //testing
    //WiFi.setSleepMode(WIFI_NONE_SLEEP);
    WiFi.setSleepMode(WIFI_LIGHT_SLEEP );
     WiFi.mode(WIFI_STA);
    Serial.print("Connecting to ");
    Serial.print(get_param("WIFI_SSID", chr));
    //Keep checking the WiFi status until it is connected to the wifi network
     int intent = 0;
  
     WiFi.status();
     while(WiFi.status()!=WL_CONNECTED){
        //Serial.print("intent ");
        Serial.print(".");    
        delay(250);
        intent ++;
        if (intent>40){
            Serial.print("\nConnection to WIFI taking time, will try later");
            break;
        }
      
       // if (intent>30) ESP.restart();
      //if (intent>20) ESP.reset();
    }
    Serial.println();
    WiFi.setAutoReconnect(true);
  //  WiFi.persistent(true);
    
    Serial.print("WiFi Connected with IP Address: ");
    Serial.println(WiFi.localIP());

    // working correctly, but: could it create a problem due to the string memory use?
    // overwriting other params?
    new (&dbclient) InfluxDBClient(get_param("INFLUXDB_URL", chr),
                                   get_param("INFLUXDB_ORG", chr),
                                   get_param("INFLUXDB_BUCKET", chr),
                                   get_param("INFLUXDB_TOKEN", chr),
                                   InfluxDbCloud2CACert
                                   );

    dbclient.setWriteOptions(WriteOptions().
                               writePrecision(WRITE_PRECISION).
                               batchSize(MAX_BATCH_SIZE).
                               bufferSize(WRITE_BUFFER_SIZE).
                               flushInterval(FLUSH_INTERVAL));


    // Giving the right name to the point.
    sensor = Point(get_param("SENSORNAME", chr));
    
    sensor.addTag("_element", "Tmeas");
    sensor.addTag("location", get_param("LOCATION", chr));

    sensor.addTag("chipID", String(ESP.getChipId(),HEX));
    timeSync(get_param("TZ_INFO", chr), "pool.ntp.org", "time.nis.gov");
    //check influxdb server connection
    if (dbclient.validateConnection()) {
      Serial.print("Connected to InfluxDB: ");
      Serial.println(dbclient.getServerUrl());
    } else {
      Serial.print("InfluxDB connection failed: ");
      Serial.println(dbclient.getLastErrorMessage());
    }  
}


//#############################################################################
// Samples to be taken in each loop
// Uncomment lines required to be logged.
//#############################################################################
void samples_to_take(){

    if(!WiFi.status()==WL_CONNECTED) check_wifistatus();//Check if ESP8266 is still connected to the internet
    loop_dl_libs();


// ##################################################
// Take continuous samples on the 6 diff channels
// NOT REQUIRED FOR CHANNELS BEING MEASSURED AS PHASES
// ##################################################
//    [channel].get_continuous_sample([sample_window_cycles],[grid_frequency]);
    //diff1.get_continuous_sample();
    //diff2.get_continuous_sample();
    //diff3.get_continuous_sample();        
    //diff4.get_continuous_sample();
    diff5.get_continuous_sample();
    diff6.get_continuous_sample();
    //Serial.println("New sampling loop");
//#############################################################################

}



//#############################################################################
// Parameters to store in the log: SD card and/or serial port.
// Uncomment lines required to be logged.
//#############################################################################
void to_log_content(){
  
// add_to_log(F("[LABEL]"), F("[UNIT]"), ([VARIABLE], [decimals]);
// All text must be inside F("")
    byte decimal_digits=2;

//Serial.println("To log contenct");

//#############################################################################
// Log for differential channels
//#############################################################################
    //add_to_log(F("DIFF1_mean"), F("mV"), diff1.mean_sample_unit(),decimal_digits);
//    add_to_log(F("DIFF1_rms"), F("mV"), diff1.rms_sample_unit(),decimal_digits);   
//    add_to_log(F("DIFF1_min"), F("mV"), diff1.min_sample_unit(),decimal_digits);       
//    add_to_log(F("DIFF1_max"), F("mV"), diff1.max_sample_unit(),decimal_digits);       
// ##################################################
    //add_to_log(F("DIFF2_mean"), F("mV"), diff2.mean_sample_unit(),decimal_digits);
//    add_to_log(F("DIFF2_rms"), F("mV"), diff2.rms_sample_unit(),decimal_digits);   
//    add_to_log(F("DIFF2_min"), F("mV"), diff2.min_sample_unit(),decimal_digits);       
//    add_to_log(F("DIFF2_max"), F("mV"), diff2.max_sample_unit(),decimal_digits);       
// ##################################################
    //add_to_log(F("DIFF3_mean"), F("mV"), diff3.mean_sample_unit(),decimal_digits);
//    add_to_log(F("DIFF3_rms"), F("mV"), diff3.rms_sample_unit(),decimal_digits);   
//    add_to_log(F("DIFF3_min"), F("mV"), diff3.min_sample_unit(),decimal_digits);       
//    add_to_log(F("DIFF3_max"), F("mV"), diff3.max_sample_unit(),decimal_digits);       
// ##################################################
    //add_to_log(F("DIFF4_mean"), F("mV"), diff4.mean_sample_unit(),decimal_digits);
//    add_to_log(F("DIFF4_rms"), F("mV"), diff4.rms_sample_unit(),decimal_digits);   
//    add_to_log(F("DIFF4_min"), F("mV"), diff4.min_sample_unit(),decimal_digits);       
//    add_to_log(F("DIFF4_max"), F("mV"), diff4.max_sample_unit(),decimal_digits);       
// ##################################################
//    add_to_log(F("DIFF5_mean"), F("mV"), diff5.mean_sample_unit(),decimal_digits);
    add_to_log(F("DIFF5_rms"), F("mV"), diff5.rms_sample_unit(),decimal_digits);   
//    add_to_log(F("DIFF5_min"), F("mV"), diff5.min_sample_unit(),decimal_digits);       
//    add_to_log(F("DIFF5_max"), F("mV"), diff5.max_sample_unit(),decimal_digits);       
// ##################################################
//    add_to_log(F("DIFF6_mean"), F("mV"), diff6.mean_sample_unit(),decimal_digits);
    add_to_log(F("DIFF6_rms"), F("mV"), diff6.rms_sample_unit(),decimal_digits);   
//    add_to_log(F("DIFF6_min"), F("mV"), diff6.min_sample_unit(),decimal_digits);       
//    add_to_log(F("DIFF6_max"), F("mV"), diff6.max_sample_unit(),decimal_digits);        

    
    sensor.clearFields();
    sensor.addField("DIFF5_rms", diff5.rms_sample_unit());
    sensor.addField("DIFF6_rms", diff6.rms_sample_unit());

                  // Print what are we exactly writing
        Serial.print("\nWriting to Influxdb: ");
        Serial.println(sensor.toLineProtocol());
        // Check WiFi connection and reconnect if needed
        if (WiFi.status() != WL_CONNECTED) {
          Serial.println("Wifi connection lost");
        }
      
        // Write point
        if (!dbclient.writePoint(sensor)) {
          Serial.print("InfluxDB write failed: ");
          Serial.println(dbclient.getLastErrorMessage());
        } 

}

void check_wifistatus(){
      switch (WiFi.status()){
      case WL_CONNECTED:
        Serial.println("Wifi WL_CONNECTED");
        break;
      case WL_NO_SSID_AVAIL:
        Serial.println("Wifi WL_NO_SSID_AVAIL");
        break;
      case WL_CONNECT_FAILED:
        Serial.println("Wifi WL_CONNECT_FAILED");
        break;
      case WL_WRONG_PASSWORD :
        Serial.println("Wifi WL_WRONG_PASSWORD ");
        break;
      case WL_IDLE_STATUS :
        Serial.println("Wifi WL_IDLE_STATUS ");
        break;
      case WL_DISCONNECTED :
        Serial.println("Wifi WL_DISCONNECTED ");
        break;
      case -1 :
        Serial.println("Wifi -1 timeout ");
        break;        
    }
  }

//bool send_influxdb(){
//    sensor.clearFields();
//    //          sensor.addField("V_meas", V_meas);
//                  // Print what are we exactly writing
//        Serial.print("Writing: ");
//        Serial.println(sensor.toLineProtocol());
//        // Check WiFi connection and reconnect if needed
//        if (WiFi.status() != WL_CONNECTED) {
//          Serial.println("Wifi connection lost");
//        }
//      
//        // Write point
//        if (!dbclient.writePoint(sensor)) {
//          Serial.print("InfluxDB write failed: ");
//          Serial.println(dbclient.getLastErrorMessage());
//        } 
//
//  
//}
