//typedef enum InputChannel_te;
//int16_t getSample(InputChannel_te ch_tag);
//int16_t prepareCh(InputChannel_te ch_tag, uint8_t gain);
//float getmVperCount(InputChannel_te ch_tag, uint8_t gain);

typedef enum InputChannel_tag {
    ch_diff1,
    ch_diff2,
    ch_diff3,
    ch_diff4,
    ch_diff5,
    ch_diff6,
    ch_se1,
    ch_se2,
    ch_se3,
    ch_se4,
    ch_se5,
    ch_se6,
    ch_se7,
    ch_se8,
    ch_se9,
    ch_se10,
    ch_se11,
    ch_se12,
} InputChannel_te;

int16_t getSample(InputChannel_te ch_tag){
    switch (ch_tag){
    case (ch_diff1): return ads4A.getConversionP0N1();
    case (ch_diff2): return ads4A.getConversionP2N3();
    case (ch_diff3): return ads4B.getConversionP0N1();
    case (ch_diff4): return ads4B.getConversionP2N3();
    case (ch_diff5): return ads4C.getConversionP0N1();
    case (ch_diff6): return ads4C.getConversionP2N3();
    default: return 0;
    }
}


int16_t prepareCh(InputChannel_te ch_tag, uint8_t gain){
    switch (ch_tag){
    case (ch_diff1): {ads4A.setGain(gain);break;}
    case (ch_diff2): {ads4A.setGain(gain);break;}
    case (ch_diff3): {ads4B.setGain(gain);break;}
    case (ch_diff4): {ads4B.setGain(gain);break;}
    case (ch_diff5): {ads4C.setGain(gain);break;}
    case (ch_diff6): {ads4C.setGain(gain);break;}
    default: return 0;
    }
}


float getmVperCount(InputChannel_te ch_tag, uint8_t gain){
    switch (ch_tag){
    case (ch_diff1): {ads4A.setGain(gain); return ads4A.getMvPerCount();}
    case (ch_diff2): {ads4A.setGain(gain); return ads4A.getMvPerCount();}
    case (ch_diff3): {ads4B.setGain(gain); return ads4B.getMvPerCount();}
    case (ch_diff4): {ads4B.setGain(gain); return ads4B.getMvPerCount();}
    case (ch_diff5): {ads4C.setGain(gain); return ads4C.getMvPerCount();}
    case (ch_diff6): {ads4C.setGain(gain); return ads4C.getMvPerCount();}
    default: return 0.;
    }
}



//-----------------------------------------------------------
// CHANNELS CONFIGURATION
// Define the parameters for each channel
//-----------------------------------------------------------
INPUTCHANNEL diff1(
    ch_diff1,            //String channel = "DIFF1";
    ADS1115_PGA_6P144,  //uint8_t gain = ADS1115_PGA_6P144;
    0.,                  //float offset = 0;
    1.                  //float mult_factor = 1;
    //"mV"                //String units = "mV"
);

INPUTCHANNEL diff2(
    ch_diff2,            //String channel = "DIFF2";
    ADS1115_PGA_6P144,  //uint8_t gain = ADS1115_PGA_6P144;
    0.,                  //float offset = 0;
    1.                  //float mult_factor = 1;
    //"mV"                //String units = "mV"
);

INPUTCHANNEL diff3(
    ch_diff3,            //String channel = "DIFF3";
    ADS1115_PGA_6P144,  //uint8_t gain = ADS1115_PGA_6P144;
    0.,                  //float offset = 0;
    1.                  //float mult_factor = 1;
    //_mV                //String units = "mV"
);

INPUTCHANNEL diff4(
    ch_diff4,            //String channel = "DIFF4";
    ADS1115_PGA_6P144,  //uint8_t gain = ADS1115_PGA_6P144;
    0.,                  //float offset = 0;
    1.                   //float mult_factor = 1;
    //_mV                //String units = "mV"
);

INPUTCHANNEL diff5(
    ch_diff5,            //String channel = "DIFF4";
    ADS1115_PGA_6P144,  //uint8_t gain = ADS1115_PGA_6P144;
    0.,                  //float offset = 0;
    1.                 //float mult_factor = 1;
    //_mV                //String units = "mV"
);

INPUTCHANNEL diff6(
    ch_diff6,            //String channel = "DIFF4";
    ADS1115_PGA_6P144,  //uint8_t gain = ADS1115_PGA_6P144;
    0.,                  //float offset = 0;
    1.                 //float mult_factor = 1;
    //_mV                //String units = "mV"
);

AC_phase phase1(&diff1,&diff4); // (I_channel, V_channel) - their offset and multiplication factor must deliver a value in V and A.
AC_phase phase2(&diff2,&diff5); // (I_channel, V_channel) - their offset and multiplication factor must deliver a value in V and A.
AC_phase phase3(&diff3,&diff6); // (I_channel, V_channel) - their offset and multiplication factor must deliver a value in V and A.


